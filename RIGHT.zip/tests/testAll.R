library(testthat)
library(RIGHT)

test_package("RIGHT")
